package university.spring_lab3_notifications.model.enums;

public enum NotificationStatus {
    CREATED,
    SENT,
    FAILED
}